<?php
session_start(); header("Content-Type: application/json");
require '../config/database.php'; require '../utils/logger.php';
$db=Database::connect();
$data=json_decode(file_get_contents("php://input"),true);

if($_GET['action']=='register'){
 $stmt=$db->prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)");
 $stmt->execute([$data['name'],$data['email'],password_hash($data['password'],PASSWORD_BCRYPT)]);
 $uid=$db->lastInsertId();
 $db->prepare("INSERT INTO wallets(user_id,balance) VALUES(?,0)")->execute([$uid]);
 echo json_encode(['message'=>'registered']);
}

if($_GET['action']=='login'){
 $stmt=$db->prepare("SELECT * FROM users WHERE email=?");
 $stmt->execute([$data['email']]);
 $u=$stmt->fetch();
 if($u && password_verify($data['password'],$u['password'])){
  $_SESSION['user_id']=$u['id'];
  logAction('LOGIN_SUCCESS',[], $u['id']);
  echo json_encode(['message'=>'ok']);
 } else echo json_encode(['error'=>'invalid']);
}
