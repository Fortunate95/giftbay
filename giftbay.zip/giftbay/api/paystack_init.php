<?php
require '../config/database.php';
session_start();

$email = $_POST['email'];
$amount = intval($_POST['amount']) * 100;

$curl = curl_init();
curl_setopt_array($curl, [
  CURLOPT_URL => "https://api.paystack.co/transaction/initialize",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => json_encode([
    "email" => $email,
    "amount" => $amount
  ]),
  CURLOPT_HTTPHEADER => [
    "Authorization: Bearer YOUR_SECRET_KEY",
    "Content-Type: application/json"
  ],
]);

$response = curl_exec($curl);
echo $response;
