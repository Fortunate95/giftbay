<?php
session_start();
require '../config/database.php';

$db = Database::connect();
$uid = $_SESSION['user_id'];
$input = $_POST['otp'];

$stmt = $db->prepare("SELECT * FROM admin_otps WHERE admin_id=? ORDER BY id DESC LIMIT 1");
$stmt->execute([$uid]);
$row = $stmt->fetch();

if(password_verify($input,$row['otp'])){
 echo json_encode(['success'=>true]);
}else{
 echo json_encode(['error'=>'invalid']);
}
