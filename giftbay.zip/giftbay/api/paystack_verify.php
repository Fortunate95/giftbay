<?php
require '../config/database.php';
require '../utils/wallet.php';

$ref = $_GET['reference'];

$curl = curl_init();
curl_setopt_array($curl, [
  CURLOPT_URL => "https://api.paystack.co/transaction/verify/".$ref,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => [
    "Authorization: Bearer YOUR_SECRET_KEY"
  ],
]);

$response = curl_exec($curl);
$result = json_decode($response, true);

if ($result['data']['status'] === 'success') {
    session_start();
    $uid = $_SESSION['user_id'];
    creditWallet($uid, $result['data']['amount']/100);
    echo json_encode(['message'=>'wallet funded']);
}
