<?php
require '../middleware/AdminAuth.php';
require '../config/database.php';

requireAdmin();
$db=Database::connect();

echo json_encode($db->query("SELECT * FROM logs ORDER BY id DESC LIMIT 100")->fetchAll());
