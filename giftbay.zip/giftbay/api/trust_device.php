<?php
session_start();
require '../config/database.php';

$db = Database::connect();
$uid = $_SESSION['user_id'];

$token = bin2hex(random_bytes(32));

$db->prepare("INSERT INTO trusted_devices(admin_id,device_token) VALUES(?,?)")
   ->execute([$uid,password_hash($token,PASSWORD_BCRYPT)]);

setcookie("trusted_device",$token,time()+86400*30,"/");

echo json_encode(['message'=>'trusted']);
