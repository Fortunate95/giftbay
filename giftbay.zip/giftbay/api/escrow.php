<?php
session_start(); header("Content-Type: application/json");
require '../config/database.php'; require '../utils/wallet.php';
$db=Database::connect();

if($_GET['action']=='create'){
 $buyer=$_SESSION['user_id'];
 $gid=$_GET['gift_id'];
 $g=$db->query("SELECT * FROM gift_cards WHERE id=$gid")->fetch();

 debitWallet($buyer,$g['price']);

 $db->prepare("INSERT INTO escrow_transactions(buyer_id,seller_id,gift_id,amount,status) VALUES(?,?,?,?, 'paid')")
    ->execute([$buyer,$g['user_id'],$gid,$g['price']]);

 echo json_encode(['message'=>'escrow created']);
}
