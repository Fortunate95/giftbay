<?php
session_start();
require '../config/database.php';
require '../utils/wallet.php';

$db = Database::connect();
$uid = $_SESSION['user_id'];
$amount = floatval($_POST['amount']);

$wallet = $db->query("SELECT balance FROM wallets WHERE user_id=$uid")->fetch();

if ($wallet['balance'] < $amount) {
    echo json_encode(['error'=>'insufficient']);
    exit;
}

debitWallet($uid, $amount);

$db->prepare("INSERT INTO withdrawals(user_id,amount,status) VALUES(?,?, 'pending')")
   ->execute([$uid,$amount]);

echo json_encode(['message'=>'withdrawal requested']);
