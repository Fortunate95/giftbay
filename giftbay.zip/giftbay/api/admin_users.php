<?php
require '../middleware/AdminAuth.php';
require '../config/database.php';

requireAdmin();
$db=Database::connect();

echo json_encode($db->query("SELECT id,name,email FROM users")->fetchAll());
