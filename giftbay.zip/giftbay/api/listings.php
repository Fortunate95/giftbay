<?php
session_start(); header("Content-Type: application/json");
require '../config/database.php';
$db=Database::connect();
$uid=$_SESSION['user_id'] ?? 0;

if($_GET['action']=='create'){
 $img=null;
 if(!empty($_FILES['image']['name'])){
  $img='uploads/'.time().$_FILES['image']['name'];
  move_uploaded_file($_FILES['image']['tmp_name'],'../'.$img);
 }
 $db->prepare("INSERT INTO gift_cards(user_id,brand,value,price,image,status) VALUES(?,?,?,?,?,'active')")
    ->execute([$uid,$_POST['brand'],$_POST['value'],$_POST['price'],$img]);
 echo json_encode(['message'=>'created']);
}

if($_GET['action']=='all'){
 echo json_encode($db->query("SELECT * FROM gift_cards WHERE status='active'")->fetchAll());
}
