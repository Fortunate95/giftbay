<?php
session_start();
require '../config/database.php';

$db = Database::connect();
$otp = rand(100000,999999);
$uid = $_SESSION['user_id'];

$db->prepare("INSERT INTO admin_otps(admin_id,otp,expires_at) VALUES(?,?,DATE_ADD(NOW(), INTERVAL 5 MINUTE))")
   ->execute([$uid,password_hash($otp,PASSWORD_BCRYPT)]);

mail("test@mail.com","OTP Code","Your OTP: $otp");

echo json_encode(['message'=>'sent']);
