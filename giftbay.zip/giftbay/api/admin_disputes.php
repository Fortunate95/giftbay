<?php
require '../middleware/AdminAuth.php';
require '../config/database.php';
require '../utils/wallet.php';

requireAdmin();
$db=Database::connect();

if($_GET['action']=='list'){
 echo json_encode($db->query("SELECT * FROM escrow_transactions WHERE status='disputed'")->fetchAll());
}

if($_GET['action']=='resolve'){
 $id=$_GET['id'];
 $type=$_GET['type'];

 $e=$db->query("SELECT * FROM escrow_transactions WHERE id=$id")->fetch();

 if($type=='release'){
  creditWallet($e['seller_id'],$e['amount']);
  $db->prepare("UPDATE escrow_transactions SET status='released' WHERE id=?")->execute([$id]);
 }

 if($type=='refund'){
  creditWallet($e['buyer_id'],$e['amount']);
  $db->prepare("UPDATE escrow_transactions SET status='refunded' WHERE id=?")->execute([$id]);
 }

 echo json_encode(['message'=>'done']);
}
