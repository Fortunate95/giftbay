<?php
session_start(); header("Content-Type: application/json");
require '../config/database.php';

$db=Database::connect();
$data=json_decode(file_get_contents("php://input"),true);

$stmt=$db->prepare("SELECT * FROM admins WHERE email=?");
$stmt->execute([$data['email']]);
$a=$stmt->fetch();

if($a && password_verify($data['password'],$a['password'])){
 $_SESSION['admin_id']=$a['id'];
 echo json_encode(['message'=>'login ok']);
}else{
 echo json_encode(['error'=>'invalid']);
}
