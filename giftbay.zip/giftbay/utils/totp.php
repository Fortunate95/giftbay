<?php
function generateTOTP($secret){
 return substr(strval(time()), -6); // simplified
}
