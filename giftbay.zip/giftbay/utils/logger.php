<?php
function logAction($action, $details=null, $user_id=null){
 require __DIR__.'/../config/database.php';
 $db=Database::connect();
 $ip=$_SERVER['REMOTE_ADDR'] ?? 'unknown';
 $db->prepare("INSERT INTO logs(user_id,action,details,ip) VALUES(?,?,?,?)")
    ->execute([$user_id,$action,json_encode($details),$ip]);
}
