<?php
function sendAlert($email,$msg){
 mail($email,"Security Alert",$msg);
}
