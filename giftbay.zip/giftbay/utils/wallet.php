<?php
function creditWallet($user_id,$amount){
 require __DIR__.'/../config/database.php';
 $db=Database::connect();
 $db->prepare("UPDATE wallets SET balance=balance+? WHERE user_id=?")
    ->execute([$amount,$user_id]);
}

function debitWallet($user_id,$amount){
 require __DIR__.'/../config/database.php';
 $db=Database::connect();
 $db->prepare("UPDATE wallets SET balance=balance-? WHERE user_id=?")
    ->execute([$amount,$user_id]);
}
