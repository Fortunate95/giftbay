<?php
class Database {
    public static function connect() {
        return new PDO(
            "mysql:host=server122.web-hosting.com;dbname=rolaxgll_giftbay;charset=utf8mb4",
            "rolaxgll_giftbay",
            "@Password2026",
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]
        );
    }
}


