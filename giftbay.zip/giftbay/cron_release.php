<?php
require 'config/database.php';
require 'utils/wallet.php';

$db = Database::connect();

$escrows = $db->query("SELECT * FROM escrow_transactions WHERE status='paid'")->fetchAll();

foreach ($escrows as $e) {
    creditWallet($e['seller_id'], $e['amount']);
    $db->prepare("UPDATE escrow_transactions SET status='released' WHERE id=?")
       ->execute([$e['id']]);
}
